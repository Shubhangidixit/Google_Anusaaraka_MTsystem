output_folder='../outputs'
#files='ls $output_folder/*.txt | sort -V'
for file in `ls $output_folder/*.txt | sort -V`;
do
 awk 'NR == 7' $file 

done

