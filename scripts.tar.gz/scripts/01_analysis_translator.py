#!/usr/bin/python

import os

files = sorted(os.listdir('../outputs'))

for file in files:
    #print file
    cmd = "awk 'NR == 7 ' "+ '../outputs/' + file
    os.system(cmd) 

