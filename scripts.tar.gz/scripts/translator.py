#!/usr/bin/python
import os

def main():
   f = open('../data/txt.done.data')
   count_line = 0
   while os.path.exists('../outputs/' + str(count_line).zfill(4) + '.txt'):
       print count_line
       count_line=count_line+1
   else:
    lines = f.readlines()
    for k in range(len(lines)):
      line = lines[count_line]  
      line = line.split('\n')[0]
      print ' I am processing the line ' + line
      text = line
      g = open('I','w')
      g.write(line + '\n')
      g.close()
      print ' I am copying the line to I'
      
      cmd = 'Anusaaraka_stanford.sh I  0 True'
      print ' Running Anusaaraka'
      os.system(cmd)
      cmd = 'cp /home/shubhangi/anu_output/I_trnsltn.html ' + '../outputs/' + str(count_line).zfill(4) + '.txt' 
      os.system(cmd)
      count_line = count_line + 1

if __name__ == '__main__':
    main()
